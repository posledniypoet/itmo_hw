package ru.ifmo.ctddev.kalinichev;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class Field {
    private int[][] field;
    private HashSet<Integer>[] rows;
    private HashSet<Integer>[] cols;
    private HashSet<Integer>[] blocks;

    public Field(int[][] field) {
        this.field = field;
        this.rows = new HashSet[9];
        this.cols = new HashSet[9];
        this.blocks = new HashSet[9];
        for (int i = 0; i < 9; i++) {
            rows[i] = new HashSet<Integer>();
            cols[i] = new HashSet<Integer>();
            blocks[i] = new HashSet<Integer>();
        }
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if (field[i][j] > 0) {
                    rows[i].add(field[i][j]);
                    cols[j].add(field[i][j]);
                    blocks[getBlock(i, j)].add(field[i][j]);
                }
            }
        }
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if ((rows[i].isEmpty() || cols[j].isEmpty() || blocks[getBlock(i, j)].isEmpty()) && field[i][j] == 0) {
                    throw new IllegalArgumentException();
                }
            }
        }
    }

    private int getBlock(int row, int col) {
        return (row / 3)*3 + (col / 3);
    }

    public String toString() {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                result.append(field[i][j]).append(' ');
            }
            result.append('\n');
        }
        return result.toString();
    }

    public HashSet<Integer> values(int row, int col) {
        HashSet<Integer> result = new HashSet<>();
        for (int i = 1; i <= 9; i++) {
            result.add(i);
        }
        result.removeAll(rows[row]);
        result.removeAll(cols[col]);
        result.removeAll(blocks[getBlock(row, col)]);
        return result;
    }

    public int getVal(int row, int col) {
        return field[row][col];
    }

    public void setVal(int row, int col, int val) {
        delVal(row, col);
        field[row][col] = val;
        rows[row].add(val);
        cols[col].add(val);
        blocks[getBlock(row, col)].add(val);
    }

    public void delVal(int row, int col) {
        rows[row].remove(field[row][col]);
        cols[col].remove(field[row][col]);
        blocks[getBlock(row, col)].remove(field[row][col]);
        field[row][col] = 0;
    }
}
