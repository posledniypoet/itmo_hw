package ru.ifmo.ctddev.kalinichev;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;

public class Game {
    private Field field;

    public void getField() {
//        Scanner in = new Scanner(System.in);
        Scanner in = new Scanner("2 0 0 0 0 5 8 9 0\n" +
                "0 6 0 0 9 0 7 1 0\n" +
                "9 0 0 7 0 0 0 0 4\n" +
                "0 0 0 0 6 0 0 5 8\n" +
                "0 0 6 0 0 0 4 0 0\n" +
                "5 9 0 0 3 0 0 0 0\n" +
                "3 0 0 0 0 8 0 0 7\n" +
                "0 4 9 0 2 0 0 8 0\n" +
                "0 8 5 1 0 0 0 0 9");
        int[][] matrix = new int[9][9];
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                matrix[i][j] = in.nextInt();
            }
        }
        field = new Field(matrix);
    }

    private Field solve(Field field) {
        boolean wasZero = false;
        int minSize = 10;
        int row = -1;
        int col = -1;
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if (field.getVal(i, j) == 0) {
                    wasZero = true;
                    if (field.values(i, j).size() < minSize) {
                        row = i;
                        col = j;
                        minSize = field.values(i, j).size();
                    }
                }
            }
        }
        if (row == -1) {
            if (wasZero) {
                throw new IllegalArgumentException();
            } else {
                return field;
            }
        }
        for (Integer integer : field.values(row, col)) {
            field.setVal(row, col, integer);
            try {
                return solve(field);
            } catch (IllegalArgumentException e) {
                continue;
            }
        }
        field.delVal(row, col);
        throw new IllegalArgumentException();
    }

    public void solve() {
        System.out.println(solve(this.field));
    }
}
