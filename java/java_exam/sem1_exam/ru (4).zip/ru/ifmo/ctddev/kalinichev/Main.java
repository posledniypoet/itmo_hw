package ru.ifmo.ctddev.kalinichev;

public class Main {
    public static void main(String[] args) {
        Game game = new Game();
        game.getField();
        game.solve();
    }
}
